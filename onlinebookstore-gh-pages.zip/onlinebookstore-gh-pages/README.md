# Online Book Store
<br/><b style="color:red font-size:30px">Welcome to Online Book Store</b><br/><br/>
This is a sample made under small mini-project for the online book store.<br/>
Under this project we have provided the facilities to search for books available in the book store ,anyone can get the details of the book and its price. <br/>
The users are also provided a profile any anyone can register login and access the onlinebookstore from anywhere. The user will not be allowed to access the website if he logs out from the store<br/>
We have also provided the facilities to select the books anyone wants to buy and also select the quantity of books to be buy. <br/> After clicking  the final button the books is purchased and the books quantity decreases from the store<br/>
We provide a final receipt to the user as the books buyed detail and price paid for further uses.<br/>
To update the book details and quantity and to add more books, we have made our website admin friendly by which the bookstore owner can easily login into the account and updates the details of the books</br>
Both the user and admin are provide the profile facility where the details of the user or admin are stored and may be updated or changed by logging in<br/>
This much is only the start of this  project and i am working hard for this  project<br/>
Suggestions are invited!<br/>

<bold>Thanks a lot</bold><br/>
                                                                                                        Project Manager<br/>
                                                                                                         <b>Shashi Raj</b>
